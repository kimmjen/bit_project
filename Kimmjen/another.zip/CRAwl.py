from bs4 import BeautifulSoup
from urllib.request import urlopen as uo
import urllib.request
from selenium import webdriver
import pandas as pd
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time
import math
import nltk
import warnings
from urllib.request import urlopen, Request
from urllib.parse import quote_plus # 한글을 유니코드 형식으로 변환해줌
from tqdm import tqdm
import os



def insta_login():
    warnings.filterwarnings(action='ignore')  # 경고 메세지 제거
    # 인스타 그램 url 생성
    baseUrl = "https://www.instagram.com/explore/tags/"
    plusUrl = input('태그 입력 : ')
    url = baseUrl + quote_plus(plusUrl)

    # 태그이름값 폴더 생성
    dir_path = './'
    dir_name = str(plusUrl)
    os.mkdir(dir_path + dir_name + '/')
    # 안보이게 웹사이트
    driver = webdriver.Chrome(executable_path='./chromedriver')
    options = webdriver.ChromeOptions()
    options.add_argument('headless')
    options.add_argument('disable-gpu')
    driver = webdriver.Chrome(executable_path='./chromedriver', options=options)
    
    driver.get(url)

    time.sleep(3)

    # # 로그인 하기
    # login_section = '//*[@id="react-root"]/section/nav/div[2]/div/div/div[3]/div/span/a[1]/button'
    # driver.find_element_by_xpath(login_section).click()
    # time.sleep(2)

    # elem_login = driver.find_element_by_name("username")
    # elem_login.clear()
    # elem_login.send_keys('')

    # elem_login = driver.find_element_by_name('password')
    # elem_login.clear()
    # elem_login.send_keys('')

    # time.sleep(4)

    # xpath = """//*[@id="react-root"]/section/main/div/article/div/div[1]/div/form/div[4]/button/div"""
    # driver.find_element_by_xpath(xpath).click()

    time.sleep(4)

    #
    SCROLL_PAUSE_TIME = 1.0
    reallink = []
    count_ = 0
    img_name_list = []

    # while True:
    while count_ < 10000:

        #
        pageString = driver.page_source
        bsObj = BeautifulSoup(pageString, 'lxml')
        
        #
        for link1 in bsObj.find_all(name='div', attrs={"class": "Nnq7C weEfm"}):
            #
            for i in range(3):
                # 이미지 저장
                try:
                    count_ = count_ + 1
                    img_name = str(plusUrl) + str(count_) + '.jpg'

                    print('이미지이름 : ' + img_name)
                    img_name_list.append(img_name)

                    title = link1.select('a')[i]
                    real = title.attrs['href']
                    reallink.append(real)
                    
                    ims_src = link1.select('img')[i].attrs['src']

                    # 폴더에 사진 저장하기
                    # urllib.request.urlretrieve(ims_src, './img' ,img_name)
                    # urllib.request.urlretrieve(ims_src, './' + plusUrl ,img_name)
                    urllib.request.urlretrieve(ims_src, './' + plusUrl +  '/' + img_name)

                except Exception as ex:
                    print(ex)

        # 끝까지 
        last_height = driver.execute_script('return document.body.scrollHeight')
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(SCROLL_PAUSE_TIME)
        new_height = driver.execute_script("return document.body.scrollHeight")

        print(last_height)
        print(last_height)

        if new_height == last_height:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(SCROLL_PAUSE_TIME)
            new_height = driver.execute_script("return document.body.scrollHeight")

            if new_height == last_height:
                break
            else:
                last_height = new_height
                continue
            # data = pd.DataFrame(reallink)
            # data.to_csv('reallink.csv', encoding='utf-8')

    print('이미지, url 수집 끝')

    # 정의
    num_of_data = len(reallink)

    print('총 {0}개의 데이터를 수집합니다.'.format(num_of_data))
    driver.close()
    
    # 받아온 사진주소 웹으로 ~~
    csvtext = []
    driver = webdriver.Chrome('./chromedriver')
    # 옵션 추가 (브라우저 띄우지 않음)
    options = webdriver.ChromeOptions()
    options.add_argument('headless')
    options.add_argument('disable-gpu')
    driver = webdriver.Chrome(executable_path='./chromedriver', options=options)

    # driver.implicitly_wait(5)

    # for i in tqdm(range(num_of_data)):
    #
    for i in range(num_of_data):
        #
        try:
            # time.sleep(1)
            # id 가져오기
            print(str(i + 1) + "번, 실제주소 : " + reallink[i])
            csvtext.append([])
            # req = Request("https://www.instagram.com/p" + reallink[i], headers={'User-Agent': 'Mozilla/5.0'})
            req = "https://www.instagram.com/p" + reallink[i]
            # dirver.get(url)
            # (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
            # p/B_CWPloB-tK/
            # time.sleep(1)
            #
            try:
                driver.get(req)
                pageString = driver.page_source
                # webpage = urlopen(req).read()
            #
            except urllib.error.URLError as ex:
                csvtext[i].append('주소없음')
                print(ex)
            # time.sleep(1)
            #
            soup = BeautifulSoup(pageString, 'lxml', from_encoding='utf-8')

            # print(soup)
            #
            csvtext[i].append(img_name_list[i])
            # time.sleep(1)
            # 위치
            try:
                location = soup.select_one('.JF9hh > a').text
                csvtext[i].append(location)
            except AttributeError as ex:
                csvtext[i].append('위치없음')
                # continue
            
            # 좋아요
            try:
                likes = soup.select_one('.sqdOP.yWX7d._8A5w5 > span').text
                csvtext[i].append(likes)
            except AttributeError as ex:
                csvtext[i].append('좋아요 없음')
                # continue
            # time.sleep(1)
            


            # location = soup.find('.Nm9Fw')
            # print(location)
            
            # likes = driver.find_element_by_xpath('//*[@id="react-root"]/section/main/div/div[1]/article/div[2]/section[2]/div/div/button/span')
            # print(likes)
            # csvtext[i].append(str(likes))

            # 해시태그 저장
            time.sleep(1)
            for reallink2 in soup.find_all('meta', attrs={'property': "instapp:hashtags"}):
                hashtags = reallink2['content'].rstrip(',')
                csvtext[i].append(hashtags)
            time.sleep(1)

            # csv로 저장
            data = pd.DataFrame(csvtext)
            data.to_csv('./' +  plusUrl + '/' +  plusUrl + '.csv', encoding='utf-8')
        except Exception as ex:
            print(ex)

    driver.close()
    print('종료')



def insta_image():
    pass

def insta_hashtag():
    pass


if __name__ == "__main__":
    print("시작")
    insta_login()
   # insta_hashtag()